function mostrarMensaje() {
    document.getElementById("mensaje").innerText = "¡Gracias por visitar! 😊";
}
